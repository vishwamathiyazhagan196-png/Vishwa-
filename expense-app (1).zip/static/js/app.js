class ExpenseManager {
  constructor() {
    this.currentEditId = null
    this.chart = null
    this.init()
  }

  init() {
    this.setupEventListeners()
    this.setDefaultDate()
    this.loadExpenses()
    this.loadDailySummary()
  }

  setupEventListeners() {
    const form = document.getElementById("expense-form")
    const cancelBtn = document.getElementById("cancel-edit")

    form.addEventListener("submit", (e) => this.handleFormSubmit(e))
    cancelBtn.addEventListener("click", () => this.cancelEdit())
  }

  setDefaultDate() {
    const dateInput = document.getElementById("date")
    const today = new Date().toISOString().split("T")[0]
    dateInput.value = today
  }

  async handleFormSubmit(e) {
    e.preventDefault()

    const formData = new FormData(e.target)
    const expenseData = {
      date: formData.get("date"),
      category: formData.get("category"),
      amount: Number.parseFloat(formData.get("amount")),
      notes: formData.get("notes") || "",
    }

    try {
      if (this.currentEditId) {
        await this.updateExpense(this.currentEditId, expenseData)
      } else {
        await this.addExpense(expenseData)
      }

      this.resetForm()
      this.loadExpenses()
      this.loadDailySummary()
    } catch (error) {
      alert("Error saving expense: " + error.message)
    }
  }

  async addExpense(expenseData) {
    const response = await fetch("/api/expenses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(expenseData),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || "Failed to add expense")
    }
  }

  async updateExpense(id, expenseData) {
    const response = await fetch(`/api/expenses/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(expenseData),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || "Failed to update expense")
    }
  }

  async deleteExpense(id) {
    if (!confirm("Are you sure you want to delete this expense?")) {
      return
    }

    try {
      const response = await fetch(`/api/expenses/${id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to delete expense")
      }

      this.loadExpenses()
      this.loadDailySummary()
    } catch (error) {
      alert("Error deleting expense: " + error.message)
    }
  }

  async loadExpenses() {
    try {
      const response = await fetch("/api/expenses")
      const expenses = await response.json()

      this.renderExpensesTable(expenses)
    } catch (error) {
      console.error("Error loading expenses:", error)
    }
  }

  renderExpensesTable(expenses) {
    const tbody = document.getElementById("expenses-tbody")
    const noExpenses = document.getElementById("no-expenses")

    if (expenses.length === 0) {
      tbody.innerHTML = ""
      noExpenses.style.display = "block"
      return
    }

    noExpenses.style.display = "none"

    tbody.innerHTML = expenses
      .map(
        (expense) => `
            <tr>
                <td>${this.formatDate(expense.date)}</td>
                <td>${expense.category}</td>
                <td class="amount">${expense.amount.toFixed(2)}</td>
                <td>${expense.notes || "-"}</td>
                <td>
                    <button class="btn-edit" onclick="expenseManager.editExpense(${expense.id})">
                        Edit
                    </button>
                    <button class="btn-delete" onclick="expenseManager.deleteExpense(${expense.id})">
                        Delete
                    </button>
                </td>
            </tr>
        `,
      )
      .join("")
  }

  editExpense(id) {
    // Find the expense data from the table
    const rows = document.querySelectorAll("#expenses-tbody tr")
    const row = Array.from(rows).find((row) => {
      const editBtn = row.querySelector(".btn-edit")
      return editBtn && editBtn.onclick.toString().includes(`editExpense(${id})`)
    })

    if (!row) return

    const cells = row.querySelectorAll("td")
    const dateStr = cells[0].textContent
    const category = cells[1].textContent
    const amount = cells[2].textContent.replace("$", "")
    const notes = cells[3].textContent === "-" ? "" : cells[3].textContent

    // Convert date format back to YYYY-MM-DD
    const date = this.parseDisplayDate(dateStr)

    // Fill the form
    document.getElementById("date").value = date
    document.getElementById("category").value = category
    document.getElementById("amount").value = amount
    document.getElementById("notes").value = notes

    // Update UI for edit mode
    this.currentEditId = id
    document.querySelector(".btn-primary").textContent = "Update Expense"
    document.getElementById("cancel-edit").style.display = "inline-block"

    // Scroll to form
    document.querySelector(".expense-form-section").scrollIntoView({ behavior: "smooth" })
  }

  cancelEdit() {
    this.resetForm()
  }

  resetForm() {
    document.getElementById("expense-form").reset()
    this.setDefaultDate()
    this.currentEditId = null
    document.querySelector(".btn-primary").textContent = "Add Expense"
    document.getElementById("cancel-edit").style.display = "none"
  }

  async loadDailySummary() {
    try {
      const response = await fetch("/api/daily-summary")
      const dailyData = await response.json()

      this.renderChart(dailyData)
    } catch (error) {
      console.error("Error loading daily summary:", error)
    }
  }

  renderChart(dailyData) {
    const ctx = document.getElementById("daily-chart").getContext("2d")

    const dates = Object.keys(dailyData).sort()
    const amounts = dates.map((date) => dailyData[date])

    if (this.chart) {
      this.chart.destroy()
    }

    this.chart = new window.Chart(ctx, {
      type: "bar",
      data: {
        labels: dates.map((date) => this.formatDate(date)),
        datasets: [
          {
            label: "Daily Spending ($)",
            data: amounts,
            backgroundColor: "rgba(102, 126, 234, 0.6)",
            borderColor: "rgba(102, 126, 234, 1)",
            borderWidth: 1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: (value) => "$" + value.toFixed(2),
            },
          },
          x: {
            ticks: {
              maxRotation: 45,
              minRotation: 45,
            },
          },
        },
        plugins: {
          tooltip: {
            callbacks: {
              label: (context) => "Spent: $" + context.parsed.y.toFixed(2),
            },
          },
        },
      },
    })
  }

  formatDate(dateStr) {
    const date = new Date(dateStr + "T00:00:00")
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    })
  }

  parseDisplayDate(displayDate) {
    // Convert "Jan 15" format back to YYYY-MM-DD
    const currentYear = new Date().getFullYear()
    const date = new Date(displayDate + ", " + currentYear)
    return date.toISOString().split("T")[0]
  }
}

// Initialize the expense manager when the page loads
const expenseManager = new ExpenseManager()
