from flask import Flask, request, jsonify, render_template
import sqlite3
import os
from datetime import datetime, timedelta
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Database setup
DATABASE = 'expenses.db'

def init_db():
    """Initialize the database with expenses table"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            category TEXT NOT NULL,
            amount REAL NOT NULL,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

def get_db_connection():
    """Get database connection"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    """Serve the main page"""
    return render_template('index.html')

@app.route('/api/expenses', methods=['GET'])
def get_expenses():
    """Get all expenses in reverse chronological order"""
    conn = get_db_connection()
    expenses = conn.execute(
        'SELECT * FROM expenses ORDER BY date DESC, created_at DESC'
    ).fetchall()
    conn.close()
    
    return jsonify([dict(expense) for expense in expenses])

@app.route('/api/expenses', methods=['POST'])
def add_expense():
    """Add a new expense"""
    data = request.get_json()
    
    if not data or not all(k in data for k in ('date', 'category', 'amount')):
        return jsonify({'error': 'Missing required fields'}), 400
    
    try:
        amount = float(data['amount'])
        if amount <= 0:
            return jsonify({'error': 'Amount must be positive'}), 400
    except ValueError:
        return jsonify({'error': 'Invalid amount'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO expenses (date, category, amount, notes) VALUES (?, ?, ?, ?)',
        (data['date'], data['category'], amount, data.get('notes', ''))
    )
    conn.commit()
    expense_id = cursor.lastrowid
    conn.close()
    
    return jsonify({'id': expense_id, 'message': 'Expense added successfully'}), 201

@app.route('/api/expenses/<int:expense_id>', methods=['PUT'])
def update_expense(expense_id):
    """Update an existing expense"""
    data = request.get_json()
    
    if not data or not all(k in data for k in ('date', 'category', 'amount')):
        return jsonify({'error': 'Missing required fields'}), 400
    
    try:
        amount = float(data['amount'])
        if amount <= 0:
            return jsonify({'error': 'Amount must be positive'}), 400
    except ValueError:
        return jsonify({'error': 'Invalid amount'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        'UPDATE expenses SET date = ?, category = ?, amount = ?, notes = ? WHERE id = ?',
        (data['date'], data['category'], amount, data.get('notes', ''), expense_id)
    )
    
    if cursor.rowcount == 0:
        conn.close()
        return jsonify({'error': 'Expense not found'}), 404
    
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Expense updated successfully'})

@app.route('/api/expenses/<int:expense_id>', methods=['DELETE'])
def delete_expense(expense_id):
    """Delete an expense"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM expenses WHERE id = ?', (expense_id,))
    
    if cursor.rowcount == 0:
        conn.close()
        return jsonify({'error': 'Expense not found'}), 404
    
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Expense deleted successfully'})

@app.route('/api/daily-summary')
def daily_summary():
    """Get daily expense totals for the last 30 days"""
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=29)
    
    conn = get_db_connection()
    expenses = conn.execute(
        'SELECT date, SUM(amount) as total FROM expenses WHERE date >= ? AND date <= ? GROUP BY date ORDER BY date',
        (start_date.isoformat(), end_date.isoformat())
    ).fetchall()
    conn.close()
    
    # Create a complete date range with zeros for missing days
    daily_totals = {}
    current_date = start_date
    while current_date <= end_date:
        daily_totals[current_date.isoformat()] = 0
        current_date += timedelta(days=1)
    
    # Fill in actual totals
    for expense in expenses:
        daily_totals[expense['date']] = float(expense['total'])
    
    return jsonify(daily_totals)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
